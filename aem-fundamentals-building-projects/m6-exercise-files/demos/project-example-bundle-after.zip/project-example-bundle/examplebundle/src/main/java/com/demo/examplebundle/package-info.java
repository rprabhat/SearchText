@Version("1.0")
@Export(optional = "provide:=true")
package com.demo.util;

import aQute.bnd.annotation.Export;
import aQute.bnd.annotation.Version;