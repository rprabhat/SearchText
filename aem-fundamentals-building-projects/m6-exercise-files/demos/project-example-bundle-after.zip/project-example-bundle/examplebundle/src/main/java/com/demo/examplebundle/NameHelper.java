package com.demo.examplebundle;

/**
 * Created by Snowbum on 10/25/2016.
 */

public class NameHelper {
    String myName = "Tyler Maynard";

    public String getMyName() {
        return myName;
    }
}